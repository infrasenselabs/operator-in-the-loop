# Class to access InfraDB2 databases.
#
# Wraps the asynchronous websocket functions in basic synchronous methods.
#
# Requires Python 3.10+ due to the use of @staticmethod and direct calling of
# them.
#
#
# Asher Hoskins
# 2020-06-07


import asyncio
import websockets
import tomli
import pandas as pd
import numpy as np

# Python Standard Library.
import json
import platform
import os
import stat
import ssl
from os.path import expanduser
from time import sleep
from datetime import timedelta


def _decode_duration(d):
    """Decode a duration string into a NumPy timedelta64, in nanoseconds.

    A duration string will look like '+1:02:03.456', with a leading plus or
    minus.

    The database shouldn't return durations in any other format but we also
    accept "+/-hh:mm" since that is a valid input format for durations.
    """

    # Detect and remove any minus sign so that we can cope with durations like
    # "-0:15" where the hours are "minus zero".
    d = d.strip()
    if d.startswith("-"):
        neg = -1
        d = d[1:]
    else:
        neg = 1

    # We split the duration into a tuple of floats at the colons and then into
    # a timedelta.
    match tuple(map(float, d.split(":"))):
        case (hours, mins, secs):
            pass
        case (hours, mins):
            secs = 0
        case _:
            raise RuntimeError(f"Badly formatted duration '{d}'")

    return np.timedelta64(neg * int((hours * 3600 + mins * 60 +
        secs) * 1e9), 'ns')


def _decode_timestamp(t):
    """Decode a timestamp into a NumPy datetime64, in nanoseconds, in the
    UTC timezone.

    InfraDB2 will always return timestamps in UTC with "+00" appended. NumPy
    doesn't handle timezones and will emit a warning if a time string with one
    is passed to it so all this function does is chop off the "+00".
    """

    return np.datetime64(t.removesuffix("+00"), 'ns')


# How to decode InfraDB2 types into Python types.
_decode_type = {
        "numeric":   np.float64,
        "string":    str,
        "timestamp": _decode_timestamp,
        "duration":  _decode_duration,
        "location":  str,
        "uuid":      str,
        "integer":   np.int64,
        "boolean":   bool}


class InfraDB2:
    """Manage connections to InfraDB2 servers."""

    def __init__(self, identity, insecure=False, verbose=False, succeed=True,
            login=True, decode_type=True):
        """Connect to an InfraDB2 server.

        Connect, and optionally login, to an InfraDB2 server.

        Args:
            identity: A websocket URL or identity name from the passwords file.
            insecure: Allow insecure WSS connections if True.
            verbose: Print all communications if True.
            succeed:
                Throw an error if a command fails if True, otherwise just
                return the reply from the server.
            login: Automatically login to the server if True.
            decode_type: Set the session to report reply types if True.

        Returns:
            An InfraDB2 object representing the connection.
        """

        # Initialise attributes.
        self.verbose = verbose
        self.succeed = succeed

        if identity is None:
            raise RuntimeError("No connection name given")
        if identity.startswith("ws:") or identity.startswith("wss:"):
            # It's a plain URL.
            self.url = identity
            username = None
            password = None
            login = False
        else:
            # Look up the name in the password file.
            (self.url, username, password) = InfraDB2.identity(identity)

        # Connect to the server.
        self.websocket = asyncio.get_event_loop().run_until_complete(
                self._do_connect(self.url, insecure))

        if login and username and password:
            # Log in automatically.
            self.login(username, password)
        if decode_type:
            # Turn on type reporting.
            self.cmd("option type=on")

        return


    @staticmethod
    def identity(name):
        """Read the details of an InfraDB2 identity.

        Read the details of an InfraDB2 identity from the password file. Throws
        an exception if the name cannot be found.

        Args:
            name: The identity name.

        Returns:
            A tuple of (URL, username, password).
        """

        with open(InfraDB2._id_file(), "rb") as f:
            config = tomli.load(f)

        if name in config:
            sect = config[name]
            if "url" not in sect:
                raise RuntimeError("Missing URL for identity")
            username = sect.get("username")
            password = sect.get("password")
            return (sect["url"], username, password)
        else:
            raise RuntimeError("Unknown identity")


    def send(self, msg):
        """Send a raw string to a websocket and wait for the reply.

        Generally the cmd() method should be used instead of this.

        Args:
            msg: The message to send.

        Returns:
            The string reply from the server.
        """

        if self.verbose:
            print(f">>> {msg}")
        reply = asyncio.get_event_loop().run_until_complete(self._do_send(msg))
        if self.verbose:
            print(f"<<< {reply}")
        return reply


    def send_json(self, msg):
        """Send a dict to a server and translate the reply back into a dict.

        Convert a dict into a JSON message as expected by an InfraDB2 server,
        send it to the server, and then wait for the reply. The reply will be
        decoded from JSON back into a dict.

        Generally the cmd() method should be used instead of this.

        Args:
            msg: A dict.

        Returns:
            A dict containing the server's reply.
        """

        return json.loads(self.send(json.dumps(msg)))


    def login(self, username=None, password=None):
        """Login to a server.

        Log in to a connected InfraDB2 server. If the "succeed" attribute is
        set then throw an exception if the login fails.

        Args:
            username: The username.
            password: The password.

        Returns:
            The reply from the server.
        """

        # We allow this function to be called as login() since that is used in
        # a lot of scripts. Now that __init__() does the login automatically
        # unless told not to we do nothing when no username or password is
        # supplied.
        if not username or not password:
            return

        if not isinstance(username, str):
            raise RuntimeError("Username must be a string")

        # We can JSON encode the password to wrap it in double quotes and also
        # escape any double quotes or backslashes that it might contain. It is
        # then safe to use in the login command without any further double
        # quotes. We check its type to prevent weirdness...
        if not isinstance(password, str):
            raise RuntimeError("Password must be a string")
        quoted_pass = json.dumps(password)
        cmd = {"cmd": f"login {username} {quoted_pass}"}
        reply = self.send_json(cmd)
        if self.succeed:
            if 'ok' not in reply:
                raise RuntimeError(f"Unable to login: {reply['error']}")
        return reply


    def cmd(self, command, data={}):
        """Send a command to a server.

        Send a command string to an InfraDB2 server, with optional extra data.
        If the "succeed" attribute is set then throw an error if the command
        fails.

        Args:
            command:
                A command string.
            data:
                A dict holding additional data to be sent along with the
                command.

        Returns:
            A dict containing the decoded reply from the server.
        """
        data["cmd"] = command
        reply = self.send_json(data)
        if self.succeed:
            if 'ok' not in reply:
                raise RuntimeError(f"Error: {reply['error']}")
        return reply


    def frame(self, command, data={}):
        """Send a command to a server and get a data frame in return.

        Send a command string to an InfraDB2 server, with optional extra data.

        The reply will be decoded into a Pandas DataFrame with the column types
        set according to the "_types" object returned by the InfraDB2 server.
        If no "_types" object is returned then throw an exception.

        This method will always throw an exception if the command fails,
        regardless of the value of the "succeed" attribute.

        Args:
            command:
                A command string.
            data:
                A dict holding additional data to be sent along with the
                command.

        Returns:
            A Pandas DataFrame holding the decoded reply from the server. Data
            types will have been converted as described above.
        """

        reply = self.cmd(command, data)
        if "ok" not in reply:
            raise RuntimeError(f"Error: {reply['error']}")

        return self._decode_reply(reply)


    def close(self):
        """Close a websocket connection."""

        if hasattr(self, "websocket"):
            asyncio.get_event_loop().run_until_complete(self.websocket.close())
            del self.websocket


    def close_connection(self):
        """Another name for close(), for legacy reasons."""
        self.close()


    def __del__(self):
        """Make sure that the connection closes when the object is deleted."""
        self.close_connection()


    @staticmethod
    def _id_file():
        """Return the path to the identity/password file.

        Return the path to the identity/password file on both Unix and Windows.
        On Unix an exception will be thrown if the file is world or group
        readable.
        """

        if platform.system() == "Windows":
            return expanduser("~/.infradb2.toml")
        else:
            filename = expanduser("~/.infradb2.toml")
            if os.stat(filename).st_mode & 0o077:
                raise RuntimeError(
                        "Password file must not be world/group readable")
            else:
                return filename


    async def _do_connect(self, url, insecure):
        """Asynchronous connection to a websocket.

        Asynchronous method to connect to a websocket.

        Args:
            url: Websocket URL (ws: or wss:).
            insecure:
                Allow connection to an insecure (e.g. SSL certificate expired)
                websocket if True.

        Returns:
            Websocket object.
        """

        if url.startswith("ws:"):
            # No SSL context needed.
            ctx = None
        else:
            ctx = ssl.create_default_context()
            if insecure:
                # Bypass certificate checks.
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE

        connection = await websockets.connect(url, ping_interval=None,
                max_size=2**24, ssl=ctx)

        return connection


    async def _do_send(self, msg):
        """Asynchronous websocket string send and receive.

        Asynchronous method to send a string to a websocket and wait for the
        reply.

        Args:
            msg: The message to send.

        Returns:
            The string reply from the server.
        """

        await self.websocket.send(msg)
        reply = await self.websocket.recv()
        return reply


    def _decode_reply(self, reply):
        """Decode a reply into a Pandas DataFrame."""

        if "_types" not in reply:
            raise RuntimeError("Cannot decode reply")

        df = pd.DataFrame()
        for (colm, datatype) in reply["_types"]:
            if datatype not in _decode_type:
                raise RuntimeError(f"Unknown data type '{datatype}'")
            if colm not in reply:
                raise RuntimeError(f"Column '{colm}' not in reply")

            data = [_decode_type[datatype](x) if x is not None else pd.NA
                    for x in reply[colm]]
            df[colm] = data

        return df

